# Projeto-netflix
Para uma pessoa especial.
<h1> Hello World! Esse projeto foi desenvolvido por mim para uma pessoa muito especial. Não se espante ao ver nossas fotos por todos os lados hahaha </h1> <br>
Ele foi desenvolvido apenas em HTML5 e CSS3, de forma estática. Não senti necessidade em utilizar JavaScript, porém, quem sabe eu traga uma atualização desse projeto no futuro. Thats it!
